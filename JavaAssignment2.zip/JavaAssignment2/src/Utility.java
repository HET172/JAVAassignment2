public class Utility {
    public static String formatCurrency(double amount) {
        return String.format("$%.2f", amount);
    }
}
